# Licence of Internal Crum's Coptic Dictionary for Mac Version 1.0.0 

Internal Crum's Coptic Dictionary for Mac 
current version: 1.0.0 

Copyright (C) 2016  So Miyagawa

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

This software's dictionary data is based on Marcion's StarDict file (2010-04-21) (https://sourceforge.net/projects/marcion/files/1.8/extras/StarDict/).

# Marcion Software's Licence

Marcion
current version: 1.8.2

Copyright (c) 2009-2015 Milan Konvicka. All rights reserved.
This software comes with ABSOLUTELY NO WARRANTY. This is free software, and you are welcome to modify and redistribute it under the GPL v2 license.